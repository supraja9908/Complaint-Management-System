module.exports={
	googleClientID : process.env.GOOGLE_CLIENT_ID,
	googleClientSecret : process.env.GOOGLE_CLIENT_SECRET,
	mongoURI : process.env.MONGO_URI,
	cookieKey: process.env.COOKIE_KEY,
	secyKey: process.env.SECY_KEY,
	adminKey: process.env.ADMIN_KEY,
	studentKey: process.env.STUDENT_KEY
}